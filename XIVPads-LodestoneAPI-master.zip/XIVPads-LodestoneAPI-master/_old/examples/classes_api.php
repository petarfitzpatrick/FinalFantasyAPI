<?php
/*  - Include the API
 *      namespace: Viion\Lodestone
 *      Alias: LodestoneAPI();
 */      
include "../api.php";

